@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Python environment is missing. Follow README.md to install dependencies.
  pause
  exit /b 1
)
echo Open http://127.0.0.1:8000/ in your browser. Press Ctrl+C to stop.
".venv\Scripts\python.exe" -m mkdocs serve --dev-addr 127.0.0.1:8000
if errorlevel 1 pause

